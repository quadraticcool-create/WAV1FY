# WAV1FY

A personal Android music player project built with Python, Kivy and Buildozer.

## Current starter features
- Add local audio files through Android's file picker
- Search imported songs by filename
- Basic play, pause, next and previous controls
- Custom artwork and persistent playlists are planned for the next development steps

## Build
The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a debug APK.
Open the repository's **Actions** tab, run **Build WAV1FY APK**, then download the artifact.

## Important
This is the first working foundation, not the finished player. Android background playback,
persistent library storage, artwork assignment, and improved metadata support will be added
in later steps and tested on-device.
