from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty, ListProperty, ObjectProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.audio import SoundLoader
from kivy.utils import platform
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.image import Image
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import os

KV = r"""
#:import dp kivy.metrics.dp
<MusicRow@Button>:
    size_hint_y: None
    height: dp(58)
    background_normal: ''
    background_color: (0,0,0,0)
    color: app.text_color
    halign: 'left'
    text_size: self.width - dp(24), None
    padding: dp(12), 0

BoxLayout:
    orientation: 'vertical'
    canvas.before:
        Color:
            rgba: app.bg_color
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        size_hint_y: None
        height: dp(68)
        padding: dp(18), dp(8)
        Label:
            text: 'WAV1FY'
            font_size: '25sp'
            bold: True
            color: app.text_color
            halign: 'left'
        Button:
            text: '+ Add music'
            size_hint_x: None
            width: dp(116)
            background_normal: ''
            background_color: app.accent
            color: (1,1,1,1)
            on_release: app.pick_music()
    TextInput:
        id: search
        hint_text: 'Search your music...'
        size_hint_y: None
        height: dp(46)
        padding: dp(14), dp(12)
        multiline: False
        background_normal: ''
        background_active: ''
        background_color: app.field_color
        foreground_color: app.text_color
        hint_text_color: app.muted
        on_text: app.filter_music(self.text)
    BoxLayout:
        size_hint_y: None
        height: dp(42)
        padding: dp(18), 0
        Label:
            text: 'YOUR LIBRARY'
            color: app.muted
            bold: True
            font_size: '12sp'
            halign: 'left'
    ScrollView:
        do_scroll_x: False
        GridLayout:
            id: songs
            cols: 1
            size_hint_y: None
            height: self.minimum_height
            spacing: dp(2)
            padding: dp(8), dp(4)
    BoxLayout:
        orientation: 'vertical'
        size_hint_y: None
        height: dp(164)
        padding: dp(16), dp(8)
        canvas.before:
            Color:
                rgba: app.panel_color
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(20)]
        Label:
            id: now_title
            text: app.now_title
            color: app.text_color
            bold: True
            font_size: '16sp'
            shorten: True
        Label:
            id: now_artist
            text: app.now_artist
            color: app.muted
            font_size: '12sp'
        BoxLayout:
            size_hint_y: None
            height: dp(48)
            spacing: dp(14)
            Button:
                text: '⏮'
                on_release: app.previous_song()
            Button:
                text: '▶ / ❚❚'
                on_release: app.toggle_play()
            Button:
                text: '⏭'
                on_release: app.next_song()
"""

class WavifyApp(App):
    now_title = StringProperty("Choose a song to begin")
    now_artist = StringProperty("Your music, your way")
    bg_color = ListProperty([0.96, 0.96, 0.94, 1])
    panel_color = ListProperty([1, 1, 1, 1])
    field_color = ListProperty([0.91, 0.92, 0.90, 1])
    text_color = ListProperty([0.12, 0.14, 0.16, 1])
    muted = ListProperty([0.43, 0.46, 0.48, 1])
    accent = ListProperty([0.34, 0.55, 0.51, 1])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.library = []
        self.filtered = []
        self.current_sound = None
        self.current_path = None
        self.current_index = -1

    def build(self):
        self.title = "WAV1FY"
        root = Builder.load_string(KV)
        self.root = root
        self.refresh_list()
        return root

    def pick_music(self):
        try:
            from plyer import filechooser
            filechooser.open_file(
                on_selection=self._music_selected,
                filters=[("Audio files", "*.mp3", "*.m4a", "*.wav", "*.ogg", "*.flac")]
            )
        except Exception as e:
            self.show_message("File picker unavailable", str(e))

    def _music_selected(self, selection):
        if not selection:
            return
        for path in selection:
            if path not in self.library:
                self.library.append(path)
        self.filter_music("")

    def filter_music(self, query):
        q = (query or "").lower().strip()
        self.filtered = [p for p in self.library if q in os.path.basename(p).lower()]
        self.refresh_list()

    def refresh_list(self):
        if not self.root:
            return
        box = self.root.ids.songs
        box.clear_widgets()
        for path in self.filtered:
            name = os.path.splitext(os.path.basename(path))[0]
            btn = Button(
                text="♫   " + name,
                size_hint_y=None, height=dp(58),
                background_normal="", background_color=(0,0,0,0),
                color=self.text_color, halign="left",
                padding=(dp(14), 0)
            )
            btn.bind(on_release=lambda _btn, p=path: self.play_path(p))
            box.add_widget(btn)

    def play_path(self, path):
        if self.current_sound:
            self.current_sound.stop()
        sound = SoundLoader.load(path)
        if not sound:
            self.show_message("Can't play this file", "Try an MP3, M4A, WAV or OGG file.")
            return
        self.current_sound = sound
        self.current_path = path
        self.current_index = self.library.index(path)
        self.now_title = os.path.splitext(os.path.basename(path))[0]
        self.now_artist = "Local audio"
        sound.play()

    def toggle_play(self):
        if not self.current_sound:
            if self.library:
                self.play_path(self.library[0])
            return
        if self.current_sound.state == "play":
            self.current_sound.stop()
        else:
            self.current_sound.play()

    def next_song(self):
        if not self.library:
            return
        self.current_index = (self.current_index + 1) % len(self.library)
        self.play_path(self.library[self.current_index])

    def previous_song(self):
        if not self.library:
            return
        self.current_index = (self.current_index - 1) % len(self.library)
        self.play_path(self.library[self.current_index])

    def show_message(self, title, message):
        Popup(title=title, content=Label(text=message),
              size_hint=(0.85, 0.35)).open()

if __name__ == "__main__":
    WavifyApp().run()
